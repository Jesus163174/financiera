@extends('layouts.admin')
@section('title','Usuarios')
@section('content')
    <div class="row" style="margin-top:20px;">
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">
                    Reporte de creditos
                </div>
                <div class="card-body">
                    <a href="" data-toggle="modal" data-target=".bd-example-modal-lg">
                        <img src="{{asset('reporte-1.png')}}" alt="" style="width: 100%;">
                    </a>
                    <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    Reportes de creditos
                                </div>
                                <div class="modal-body">
                                    <ul class="nav nav-tabs" id="myTab" role="tablist">
                                        <li class="nav-item">
                                            <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">Creditos del dia</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="false">Creditos por fecha</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" id="contact-tab" data-toggle="tab" href="#contact" role="tab" aria-controls="contact" aria-selected="false">Creditos Atrasados</a>
                                        </li>
                                    </ul>
                                    <div class="tab-content" id="myTabContent">
                                        <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab" style="height: 400px !important; overflow-y: scroll;">
                                            <div class="div" style="display: flex; justify-content: space-between; align-items: center; padding: 10px;">
                                                <a href="" class="btn btn-success btn-sm">Exportar PDF</a>
                                                <div>
                                                    <strong>Dinero Total Prestado: ${{number_format($sumDineroPrestado,2,'.',',')}}</strong> <br>
                                                    <strong>Ganancias: ${{number_format($ganancias,2,'.',',')}}</strong>
                                                </div>
                                            </div>
                                            <div class="table-responsive">
                                                <table class="table table-borded">
                                                    <thead>
                                                        <tr>
                                                            <th>Prestado</th>
                                                            <th>Total</th>
                                                            <th>Cobrador</th>
                                                            <th>Cliente</th>
                                                            <th>Pagos</th>
                                                            <th>Pagos diarios</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        @foreach($dayCredits as $credit)
                                                            <tr>
                                                                <td>${{number_format($credit->totalamount,2,'.',',')}}</td>
                                                                <td>${{number_format($credit->total,2,'.',',')}}</td>
                                                                <td>
                                                                    {{$credit->lender->name}}
                                                                </td>
                                                                <td>
                                                                    {{$credit->customer->fullname}}
                                                                </td>
                                                                <td>
                                                                    {{$credit->totalpayments}}
                                                                </td>
                                                                <td>
                                                                    ${{number_format($credit->dayPayments,2,'.',',')}}
                                                                </td>
                                                            </tr>
                                                        @endforeach
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                        <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">...</div>
                                        <div class="tab-pane fade" id="contact" role="tabpanel" aria-labelledby="contact-tab">...</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@stop