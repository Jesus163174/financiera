@extends('layouts.admin')
@section('title','Usuarios')
@section('content')
    {{--<div class="row" style="margin-top:20px;">
        <div class="col-md-4">
            <ul class="list-group">
                <li class="list-group-item"><strong>Total a pagar: ${{number_format($credit->total,2,'.',',')}}</strong></li>
                <li class="list-group-item"><strong>Cantidad Prestada: ${{number_format($credit->totalamount,2,'.',',')}}</strong></li>
            </ul>
        </div>
        <div class="col-md-4">
            <ul class="list-group">
                <li class="list-group-item"><strong>Total de pagos: </strong> {{$credit->totalpayments}}</li>
                <li class="list-group-item"><strong>Pagado: </strong> ${{$credit->pagado($credit->id)}}</li>
            </ul>
        </div>
        <div class="col-md-4">
            <ul class="list-group" style="color:red; font-weight: bold;">
                <li class="list-group-item"><strong>Por pagar: </strong> ${{number_format($credit->faltante($credit->id,$credit->total),2,'.',',')}}</li>
                <li class="list-group-item"><strong>Pagos Diarios: </strong> ${{number_format($credit->dayPayments,2,'.',',')}}</li>
            </ul>
        </div>
    </div>
    <div class="row" style="margin-top:20px;">
        @for($i = 0; $i< $credit->totalpayments; $i++)
            <div class="col-md-3">
                <div class="card" style="margin: 10px 3px; padding:3px;">
                    <div class="card-header">
                        Pago {{$i+1}}
                    </div>
                    <div class="card-body">
                        @if($credit->dayNPay($i+1,$credit->id) == 1)
                            @if($credit->totalPayDay($credit->id,$i+1,$credit->dayPayments) == 1)
                                <a href="">Pagado</a>
                            @else
                                <a href="">Resta: {{$credit->totalPayDay($credit->id,$i+1,$credit->dayPayments)}}</a>
                                @if($i+1 == $credit->totalpayments and $credit->totalPayDay($credit->id,$i+1,$credit->dayPayments) != 1)
                                    <button class="btn btn-success form-control btn-sm" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong-{{$i}}">Pagar</button>
                                    <form action="{{asset('admin/creditos/pagar')}}" method="post">
                                        @csrf
                                        <input type="hidden" value="{{$i+1}}" name="numberPay">
                                        <input type="hidden" value="{{$credit->id}}" name="credit_id">
                                        <input type="hidden" value="{{$credit->customer_id}}" name="customer_id">
                                        <div class="modal fade" id="exampleModalLong-{{$i}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle">Registrar pago</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="">Ingresa la cantidad a pagar</label>
                                                            <input type="number" required step="any" placeholder="Pago Numero: {{$i+1}}" name="payment" class="form-control form-control-lg" >
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">Registrar pago</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                @endif
                            @endif
                        @else
                            <button class="btn btn-success form-control btn-sm" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong-{{$i}}">Pagar</button>
                            <form action="{{asset('admin/creditos/pagar')}}" method="post">
                                @csrf
                                <input type="hidden" value="{{$i+1}}" name="numberPay">
                                <input type="hidden" value="{{$credit->id}}" name="credit_id">
                                <input type="hidden" value="{{$credit->customer_id}}" name="customer_id">
                                <div class="modal fade" id="exampleModalLong-{{$i}}" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLongTitle">Registrar pago</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="">Ingresa la cantidad a pagar</label>
                                                    <input type="number" required step="any" placeholder="Pago Numero: {{$i+1}}" name="payment" class="form-control form-control-lg" >
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Registrar pago</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        @endif
                    </div>
                </div>
            </div>
        @endfor
    </div>--}}
    <div class="row">
        <div class="col-md-8 col-lg-8 col-xs-12 col-sm-12" style="margin-top:20px;">
            <ul class="list-group">
            <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Fecha: </strong><span style="font-size:1.4em; font-weight:bold; color:green;">{{now()->format('Y-m-d')}}</span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Numero de pago: </strong><span style="font-size:1.4em; font-weight:bold; color:green;">{{$paymentsMade}} - {{$credit->totalpayments}}</span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Pago del día: </strong><span style="font-size:1.4em; font-weight:bold; color:green;">${{number_format($credit->dayPayments,2,'.',',')}}</span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Pagado: </strong><span style="font-size:1.4em; font-weight:bold; color:red;">${{number_format($pagado,2,'.',',')}}</span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Resta: </strong><span style="font-size:1.4em; font-weight:bold; color:red;">${{number_format($resta,2,'.',',')}}</span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Estatus: </strong><span style="font-size:1.4em; font-weight:bold; color:red;">{{$credit->status}}</span>
                </li>
            </ul> <br>
            <div class="card">
                <div class="card-header">
                    Agregar un nuevo pago
                </div>
                <form action="{{asset('admin/creditos/pagar')}}" method="post">
                    @csrf
                    <input type="hidden" name="credit_id" value="{{$credit->id}}">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Ingresa el pago: </label>
                            <input required type="number" class="form-control" name="payment" step="any">
                        </div>
                        <button class="btn btn-success" type="submit">Agregar pago</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4 col-lg-4 col-xs-12 col-sm-12" style="margin-top:20px;">
            <div class="card">
                <div class="card-header text-center">
                    <h4 class="title">Historial de pagos</h4>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        @foreach($pays as $pay)
                        <li class="list-group-item">
                            Numero de pago: {{$pay->numberPay}} <br>
                            Fecha: {{now()->format('Y-m-d')}} <br>
                            Monto: ${{number_format($pay->payment,2,'.',',')}}
                        </li>
                        @endforeach
                    </ul>
                </div>
            </div>
        </div>
    </div>

@stop