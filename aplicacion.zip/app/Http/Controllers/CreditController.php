<?php

namespace App\Http\Controllers;

use App\PaymentHistory;
use Illuminate\Http\Request;
use App\Credit;
use App\Customer;
use Carbon\Carbon;
use App\PayHistoryRenew;
use Illuminate\Support\Facades\Auth;

class CreditController extends Controller{

    public function index(){
        $credits = Credit::credits()->get();
        $results = new Credit();
        return view('credits.index',compact('credits','results'));
    }
    public function create(){
        $customers = Customer::customers()->get();
        $credit = new Credit();
        return view('credits.create',compact('customers','credit'));
    }
    public function store(Request $request){
        try{
            $credit    = new Credit();
            $validated = $credit->validate($request);
            $wainnings = $credit->applyPercentage($request->totalamount);
            $validated['wainnings'] = $wainnings;
            $validated['lender_id'] = Auth::user()->id;
            $validated['date'] = Carbon::now()->format('Y-m-d');
            $validated['initialDate'] = Carbon::now()->addDay(1);
            $validated['finishDate']  = Carbon::now()->addDays($validated['totalpayments']);
            $validated['total'] = $wainnings + $validated['totalamount'];
            $validated['dayPayments'] = $validated['total']/$validated['totalpayments'];
            $credit->store($validated);
            $msj = "El credito fue agregado correctamente";
            try{
                $clientChangeStatus = Customer::lend(Customer::find($validated['customer_id']));
            }catch(\Exception $e){
                dd($e->getMessage());
            }
            return redirect('admin/creditos')->with('status_success',$msj); 
        }catch(Exception $e){
            dd($e->getMessage());
        }
    }
    public function  pay(Request $request){ 
        //dd($request);
        $credit = Credit::find($request->credit_id);
        $paymentsMade =  PaymentHistory::where('credit_id',$credit->id)->orderBy('numberPay','desc')->count();

        $addPay = new PaymentHistory();
        $addPay->customer_id = 	$credit->customer_id;
        $addPay->lender_id   =  $credit->lender_id;
        $addPay->paymentDate = now()->format('Y-m-d');
        $addPay->numberPay   = $paymentsMade+1;
        $addPay->payment     = $request->payment;
        $addPay->credit_id   = $credit->id;
        $addPay->estatus      = "pagado";
        $addPay->paymentDateCurrent = now()->format('Y-m-d');

        $pagado = PaymentHistory::where('credit_id',$credit->id)->sum('payment');
        if($credit->total == $pagado){
            $credit->status = 'pagado';
            $credit->save();
        }
        $addPay->save();
        return back();
    }
    public function show($id){
        $credit = Credit::find($id);
        $paymentsMade =  PaymentHistory::where('credit_id',$credit->id)->orderBy('numberPay','desc')->count();
        $sumPay = PaymentHistory::where('credit_id',$credit->id)->sum('payment');
        $resta  = $credit->total - $sumPay;
        $pagado = PaymentHistory::Where('credit_id',$credit->id)->sum('payment');

        #historial de pagos de creditos
        $pays = PaymentHistory::where('credit_id',$credit->id)->get();
        return view('credits.show',compact('credit','paymentsMade','resta','pays','pagado'));
    }
    public function edit($id){
        $credit = Credit::find($id);
        $customers = Customer::customers()->get();
        return view('credits.edit',compact('credit','customers'));
    }
    public function update(Request $request, $id){
        //
    }
    public function destroy($id){
        //
    }
}
