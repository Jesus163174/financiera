<div class="table-responsive">
    <table class="table table-bordered">
        <thead>
            <th class="text-center">Nombre</th>
            <th class="text-center">Email</th>
            <th class="text-center">Telefono</th>
            <th class="text-center">Cobrador</th>
            <th class="text-center">Fecha</th>
            <?php if(Auth::user()->rol == 'administrador'): ?>
                <th class="text-center">Acciones</th>
            <?php endif; ?>
        </thead>
        <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="text-center"><?php echo e($customer->fullname); ?></td>
                    <td class="text-center"><?php echo e($customer->email); ?></td>
                    <td class="text-center"><?php echo e($customer->phone); ?></td>
                    <td class="text-center"><?php echo e($customer->registro->name); ?></td>
                    <td class="text-center"><?php echo e($customer->created_at); ?></td>
                    <?php if(Auth::user()->rol == 'administrador'): ?>
                        <form action="<?php echo e(asset('admin/clientes/'.$customer->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <?php echo e(method_field('delete')); ?>

                            <td class="text-center">
                                <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                            </td>
                        </form>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/customers/data.blade.php ENDPATH**/ ?>