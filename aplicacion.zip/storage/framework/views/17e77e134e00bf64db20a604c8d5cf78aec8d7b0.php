<?php $__env->startSection('title','Usuarios'); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="row">
        <div class="col-md-8 col-lg-8 col-xs-12 col-sm-12" style="margin-top:20px;">
            <ul class="list-group">
            <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Fecha: </strong><span style="font-size:1.4em; font-weight:bold; color:green;"><?php echo e(now()->format('Y-m-d')); ?></span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Numero de pago: </strong><span style="font-size:1.4em; font-weight:bold; color:green;"><?php echo e($paymentsMade); ?> - <?php echo e($credit->totalpayments); ?></span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Pago del día: </strong><span style="font-size:1.4em; font-weight:bold; color:green;">$<?php echo e(number_format($credit->dayPayments,2,'.',',')); ?></span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Pagado: </strong><span style="font-size:1.4em; font-weight:bold; color:red;">$<?php echo e(number_format($pagado,2,'.',',')); ?></span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Resta: </strong><span style="font-size:1.4em; font-weight:bold; color:red;">$<?php echo e(number_format($resta,2,'.',',')); ?></span>
                </li>
                <li class="list-group-item">
                    <strong style="color:#333; font-size:1.4em; font-weight:bold;">Estatus: </strong><span style="font-size:1.4em; font-weight:bold; color:red;"><?php echo e($credit->status); ?></span>
                </li>
            </ul> <br>
            <div class="card">
                <div class="card-header">
                    Agregar un nuevo pago
                </div>
                <form action="<?php echo e(asset('admin/creditos/pagar')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="credit_id" value="<?php echo e($credit->id); ?>">
                    <div class="card-body">
                        <div class="form-group">
                            <label for="">Ingresa el pago: </label>
                            <input required type="number" class="form-control" name="payment" step="any">
                        </div>
                        <button class="btn btn-success" type="submit">Agregar pago</button>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-md-4 col-lg-4 col-xs-12 col-sm-12" style="margin-top:20px;">
            <div class="card">
                <div class="card-header text-center">
                    <h4 class="title">Historial de pagos</h4>
                </div>
                <div class="card-body">
                    <ul class="list-group">
                        <?php $__currentLoopData = $pays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pay): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-group-item">
                            Numero de pago: <?php echo e($pay->numberPay); ?> <br>
                            Fecha: <?php echo e(now()->format('Y-m-d')); ?> <br>
                            Monto: $<?php echo e(number_format($pay->payment,2,'.',',')); ?>

                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/credits/show.blade.php ENDPATH**/ ?>