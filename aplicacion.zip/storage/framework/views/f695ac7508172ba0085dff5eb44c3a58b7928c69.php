<div class="form-group">
    <label for="" class="label-w">Nombre</label>
    <input type="text" required value="<?php echo e($employe->name); ?>"   name="name" class="form-control form-control-lg"
        placeholder="Ingresa el nombre completo del cobrador">
        <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
    <label for="" class="label-w">Email</label>
    <input type="email" required  value="<?php echo e($employe->email); ?>" name="email" class="form-control form-control-lg"
        placeholder="Ingresa el email del cobrador">
        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
    <label for="" class="label-w">Contraseña</label>
    <input type="password" <?php if(!isset($employe)): ?> required <?php endif; ?> name="password"  class="form-control form-control-lg"
        placeholder="Ingresa la contraseña del cobrador">
        <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($message); ?></strong>
            </span>
        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
    <label for="" class="label-w">Repite la Contraseña</label>
    <input type="password"  <?php if(!isset($employe)): ?> required <?php endif; ?> name="password_confirmation" class="form-control form-control-lg"
        placeholder="Repite la contraseña">
</div>
<div class="form-group">
    <label for="" class="label-w">Selecciona un rol</label>
    <select name="rol" class="form-control form-control-lg" id="">
        <option value="" selected><?php if($employe->rol == null): ?> Selecciona un rol <?php else: ?> <?php echo e($employe->rol); ?> <?php endif; ?></option>
        <option value="admin">1.Administrador</option>
        <option value="cobrador">2.Cobrador</option>
    </select>
    <?php if ($errors->has('rol')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('rol'); ?>
        <span class="invalid-feedback" role="alert">
            <strong><?php echo e($message); ?></strong>
        </span>
    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
</div>
<div class="form-group">
    <button class="btn btn-success">Agregar</button>
</div><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/employees/form.blade.php ENDPATH**/ ?>