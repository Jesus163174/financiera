<?php $__env->startSection('title','Usuarios'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row top-md">
        <div class="col-md-12 col-xs-12 col-sm-12 col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="title">Listado de gastos</h3>
                    <span>Total general: $<?php echo e(number_format($total,2,'.',',')); ?></span> <br>
                    <span>Total del día: $<?php echo e(number_format($totalDia,2,'.',',')); ?></span> <br>
                    <a class="btn btn-success btn-sm" href="/admin/gastos/create">Agregar Gasto</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Monto</th>
                                    <th>Fecha</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $gastos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gasto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>$<?php echo e(number_format($gasto->monto,2,'.',',')); ?></td>
                                        <td><?php echo e($gasto->created_at); ?></td>
                                        <td><?php echo e($gasto->descripcion); ?></td>
                                        <td>
                                            <form action="<?php echo e(asset('admin/gastos/'.$gasto->id)); ?>" method="post">
                                                <?php echo e(method_field('delete')); ?>

                                                <?php echo csrf_field(); ?>
                                                <button type="submit"  class="btn btn-danger">Eliminar</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/gastos/index.blade.php ENDPATH**/ ?>