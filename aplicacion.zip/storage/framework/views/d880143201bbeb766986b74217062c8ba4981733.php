<?php $__env->startSection('title','Cobradores'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row mg-top-md">
        <div class="col-md-12">
            <?php if(!empty(Session::get('status_success'))): ?> 
                <div class="alert alert-success alert-dismissible fade show mb-0" role="alert">
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                    <i class="fa fa-check mx-2"></i>
                    <strong><?php echo e(Session::get('status_success')); ?></strong> 
                </div>
            <?php endif; ?>
            <br>
        </div> 
        <div class="col-md-12 card-enable">
            <a href="<?php echo e(asset('admin/cobradores/create')); ?>" class="btn btn-success mg-b-md">Agregar nuevo</a>
            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="data-table" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">Nombre</th>
                                    <th class="text-center">Email</th>
                                    <th class="text-center">Fecha de creacion</th>
                                    <th class="text-center">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($employe->name); ?></td>
                                    <td class="text-center"><?php echo e($employe->email); ?></td>
                                    <td class="text-center"><?php echo e($employe->created_at); ?> </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(asset('admin/cobradores/'.$employe->id)); ?>" class="btn btn-info">Detalle</a>
                                        <a href="<?php echo e(asset('admin/cobradores/'.$employe->id.'/edit')); ?>" class="btn btn-success">Editar</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($employees->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/employees/index.blade.php ENDPATH**/ ?>