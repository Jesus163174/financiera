<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Reporte de creditos</title>
        <link rel="stylesheet" href="style.css" media="all" />
    </head>
    <body>
        <header class="clearfix">
            
            <h1>Vendedor: <?php echo e($vendedor->name); ?></h1>
            <div id="project">
                <div><span>Reporte: </span> Creditos por vendedor</div>
                <div><span>Fecha: </span> <?php echo e(now()->format('Y-m-d')); ?></div>
                <div><span>N° de creditos: </span> <?php echo e(count($creditos)); ?></div>
                <div><span>Dinero de cobros: </span> $<?php echo e(number_format($dineroPagado,2,'.',',')); ?></div>
                <div><span>Dinero Prestado: </span> $<?php echo e(number_format($sumaDineroPrestado,2,'.',',')); ?></div>
                
            </div>
        </header>
        <main>
            <table>
                <thead>
                    <tr>
                        <th  class="">Cliente</th>
                        <th    class="">Fecha</th>
                        <th  >Pago</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class=""><?php echo e($pago->customer->fullname); ?></td>
                        <td class=""><?php echo e($pago->created_at); ?></td>
                        <td class="">$<?php echo e(number_format($pago->payment,2,'.',',')); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            
        </main>
        
    </body>
</html>

<?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/reports/vendedores-pdf.blade.php ENDPATH**/ ?>