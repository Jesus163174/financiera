<?php $__env->startSection('title','Usuarios'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row top-md">
        <div class="col-md-12 col-lg-12 col-xs-12 col-sm-12">
           <div class="card card-small mb-4">
               <div class="card-header  border-bottom">
                <h6 class="m-0">Registrar Cliente</h6>
               </div>
               <div class="card-body">
                    <form action="<?php echo e(asset('admin/clientes')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('customers.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
               </div>
           </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/customers/create.blade.php ENDPATH**/ ?>