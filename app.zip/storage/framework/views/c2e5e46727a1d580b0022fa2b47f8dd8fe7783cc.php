<div class="card card card-small mb-4 bm-md enable">
    <div class="card-header border-bottom">
        <h6 class="m-0">
            <?php echo e($title); ?>(<?php echo e($count); ?>)
        </h6>
    </div>
    <div class="card-body">
        <?php echo $__env->make($data, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php echo $__env->make($mobile, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/layouts/card.blade.php ENDPATH**/ ?>