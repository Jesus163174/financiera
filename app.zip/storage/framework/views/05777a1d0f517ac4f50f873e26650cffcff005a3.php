<?php $__env->startSection('title','Usuarios'); ?>
<?php $__env->startSection('content'); ?>
<div class="row top-md">
    <div class="col-lg-12">
        <div class="card card-small mb-4">
            <div class="card-header border-bottom">
                <h6 class="m-0">Registrar Usuario</h6>
            </div>
            <ul class="list-group list-group-flush">
                <li class="list-group-item p-3">
                    <div class="row">
                        <div class="col">
                            <form action="<?php echo e(asset('admin/usuarios')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </form>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/users/create.blade.php ENDPATH**/ ?>