<?php $__env->startSection('title','Usuarios'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row" style="margin-top:20px;">
        <div class="col-md-4">
            <ul class="list-group">
                <li class="list-group-item"><strong>Total a pagar: $<?php echo e(number_format($credit->total,2,'.',',')); ?></strong></li>
                <li class="list-group-item"><strong>Cantidad Prestada: $<?php echo e(number_format($credit->totalamount,2,'.',',')); ?></strong></li>
            </ul>
        </div>
        <div class="col-md-4">
            <ul class="list-group">
                <li class="list-group-item"><strong>Total de pagos: </strong> <?php echo e($credit->totalpayments); ?></li>
                <li class="list-group-item"><strong>Pagado: </strong> $<?php echo e($credit->pagado($credit->id)); ?></li>
            </ul>
        </div>
        <div class="col-md-4">
            <ul class="list-group" style="color:red; font-weight: bold;">
                <li class="list-group-item"><strong>Por pagar: </strong> $<?php echo e(number_format($credit->faltante($credit->id,$credit->total),2,'.',',')); ?></li>
                <li class="list-group-item"><strong>Pagos Diarios: </strong> $<?php echo e(number_format($credit->dayPayments,2,'.',',')); ?></li>
            </ul>
        </div>
    </div>
    <div class="row" style="margin-top:20px;">
        <?php for($i = 0; $i< $credit->totalpayments; $i++): ?>
            <div class="col-md-3">
                <div class="card" style="margin: 10px 3px; padding:3px;">
                    <div class="card-header">
                        Pago <?php echo e($i+1); ?>

                    </div>
                    <div class="card-body">
                        <?php if($credit->dayNPay($i+1,$credit->id) == 1): ?>
                            <?php if($credit->totalPayDay($credit->id,$i+1,$credit->dayPayments) == 1): ?>
                                <a href="">Pagado</a>
                            <?php else: ?>
                                <a href="">Resta: <?php echo e($credit->totalPayDay($credit->id,$i+1,$credit->dayPayments)); ?></a>
                                <?php if($i+1 == $credit->totalpayments and $credit->totalPayDay($credit->id,$i+1,$credit->dayPayments) != 1): ?>
                                    <button class="btn btn-success form-control btn-sm" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong-<?php echo e($i); ?>">Pagar</button>
                                    <form action="<?php echo e(asset('admin/creditos/pagar')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="<?php echo e($i+1); ?>" name="numberPay">
                                        <input type="hidden" value="<?php echo e($credit->id); ?>" name="credit_id">
                                        <input type="hidden" value="<?php echo e($credit->customer_id); ?>" name="customer_id">
                                        <div class="modal fade" id="exampleModalLong-<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLongTitle">Registrar pago</h5>
                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label for="">Ingresa la cantidad a pagar</label>
                                                            <input type="number" required step="any" placeholder="Pago Numero: <?php echo e($i+1); ?>" name="payment" class="form-control form-control-lg" >
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="submit" class="btn btn-primary">Registrar pago</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <button class="btn btn-success form-control btn-sm" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong-<?php echo e($i); ?>">Pagar</button>
                            <form action="<?php echo e(asset('admin/creditos/pagar')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($i+1); ?>" name="numberPay">
                                <input type="hidden" value="<?php echo e($credit->id); ?>" name="credit_id">
                                <input type="hidden" value="<?php echo e($credit->customer_id); ?>" name="customer_id">
                                <div class="modal fade" id="exampleModalLong-<?php echo e($i); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                                    <div class="modal-dialog" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLongTitle">Registrar pago</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">&times;</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="form-group">
                                                    <label for="">Ingresa la cantidad a pagar</label>
                                                    <input type="number" required step="any" placeholder="Pago Numero: <?php echo e($i+1); ?>" name="payment" class="form-control form-control-lg" >
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Registrar pago</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endfor; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/credits/show.blade.php ENDPATH**/ ?>