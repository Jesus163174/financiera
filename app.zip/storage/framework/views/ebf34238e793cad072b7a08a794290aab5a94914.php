<?php $__env->startSection('title','Usuarios'); ?>
<?php $__env->startSection('content'); ?>
    <div class="row top-md">
        <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
            <div class="card card card-small mb-4 bm-md">
                <div class="card-header border-bottom">
                    <h6 class="m-0">Registrar nuevo credito</h6>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(asset('admin/creditos')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <?php echo $__env->make('credits.form',['button'=>"Agregar"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </form>
                </div>
            </div> 
        </div>
    </div>  
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $('.js-example-basic-single').select2();
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuario\Documents\inusual software\financiera\app\resources\views/credits/create.blade.php ENDPATH**/ ?>